//
// Created by ISEN on 13/02/2024.
//

#include "define.h"
#include "frame.h"
#include "ftd2xx.h"
#include "usb.h"


FT_HANDLE initUSB(){
    FT_HANDLE ftHandle;

    return ftHandle;

}
void closeUSB(FT_HANDLE ftHandle){

}


void writeUSB(char* frame, FT_HANDLE ftHandle){


}